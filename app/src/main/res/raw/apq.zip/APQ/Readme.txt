中文版本：
本软件是安卓绿色版QEMU虚拟机，有相应的安卓应用APQ-0.4.1.apk作为前端界面，用于启动和管理虚拟机。
所用的后端QEMU为绿色版，不限于安卓，使用Linux内核、CPU为arm、支持硬件浮点的机器理论上应该都可以运行。
此版本0.4.1支持使用sdl和vnc图形界面，虚拟机网络支持user和tap静态IP。

一、 安装要求
1. 具有root权限
2. cpu支持arm硬件浮点运算，即armhf。

二、新特性：
1. 支持X86的机器（请下载APQ-0.4.1-X86.apk使用）；
1. 支持模拟arm的机器；
2. 修正多用户模式下镜像目录;

二、使用说明
1. 对于一般用户，建议直接下载APQ的apk，安装后按提示进行操作就可以了。
目前的apk只有“懒人完全版”，也就是内置了压缩的绿色版QEMU，使用时会提示需要解压到/data分区的一个目录。
以后可能会发布“绿色简洁版”，不带QEMU数据包，只用于启动QEMU。

对于绿色版，下载“APQ-版本号.zip”压缩包。
解压后把整个APQ目录放在SD卡目录下，把测试用kolibri.img镜像也放在此目录下。
终端应用中输入以下命令，或者将其作为终端的初始命令：
su -c 'cd /sdcard/APQ; sh runvm kobibri.conf'
就可以启动KolibriOS。

2. 为了获得更快的速度、稳定性和避免一些意想不到问题（理论上）
终端应用中输入：
su -c 'cd /sdcard/APQ; sh INSTALL‘
按提示操作即可。


3. 自定义虚拟机
kolibri.conf是例子文件，中间有很详细的中文说明。依照kolibri.conf，你可以容易地写制自己的虚拟机配置文件。
比如：放一个名叫95.conf的文件到APQ目录下，复制xp.conf为95.conf，然后修改-hda /sdcard/win95.img。


四、许可证：
只用于个人使用和研究用途，不得用于商业用途。
总体来说，本软件基于QEMU官方源码2.2.50版本构建，遵守QEMU的GPL协议，lib目录下的库文件都是从Ubuntu 14.04 armhf版官方构建的版本中复制过来的，也基于GPL协议。busybox为官方源码编译。tunctl也基于网上的版本，目前暂时未整理，后期也将基于GPL协议发布。

Email: felonwan@gmail.com


English Version:
QEMU build for armhf machines with linux kernel, such as Android or other Linux distributions.

This version 0.4.1 is build with:
Graphic support of sdl and vnc

1. Requirements
a. root previlege
b. Hard float computing is required, i.e. armhf is required.

2. Installation
Install and Open a terminal application, input
su -c 'path/INSTALL‘
and follow the instructions, 'path' is the decompressed files exist.

3. Usage
Input following commands or set it to be the inital command of terminal applications:
su -c 'cd /sdcard/APQ; sh runvm kolibri.conf'

LICENCE:
No commercial use, personal use and reasearch use only.
In general, the software is build with official QEMU source codes of version 2.2.50， follow GPL v2 licence of QEMU, except directory 'lib' contains libraries which are copied from official Ubuntu 14.04 armhf  with GPL licence.

Email: felonwan@gmail.com
